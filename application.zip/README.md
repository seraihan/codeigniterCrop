# CodeIgniter 2
Open Source PHP Framework (originally from EllisLab)

For more info, please refer to the user-guide at http://www.codeigniter.com/userguide2/  
(also available within the download package for offline use)

**WARNING:** *CodeIgniter 2.x is no longer under development and only receives security patches until October 31st, 2015.
Please update your installation to the latest CodeIgniter 3.x version available
(upgrade instructions [here](http://www.codeigniter.com/userguide3/installation/upgrade_300.html)).*

***About:
It's a image croper. By helping with JCrop. JCrop is a JQuery plugin. Then use Codeigniter.



***Note for test use: 
1) At first you keep it in your root directory. For example www or htdocs. 
2) Then you go http://127.0.0.1/cicrop/index.php/user/upload

